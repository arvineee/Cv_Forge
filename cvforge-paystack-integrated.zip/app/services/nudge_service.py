"""
CVForge AI - Pro-upgrade nudge service

Single source of truth for "who gets a Pro-upgrade reminder email and
when." Used by:
  - the existing `flask send-nudges` CLI command in app/cli.py (wire it
    to call send_pro_upgrade_nudges() below instead of whatever inline
    query it currently has, so the CLI and the admin panel can never
    disagree on who's eligible)
  - the new manual "Send reminders now" button on /admin/nudges

Save this as app/services/nudge_service.py.
"""
from datetime import timedelta
from app.models import db, User, UserSettings, Notification, utcnow

# Don't nudge the same free user more than once a week.
NUDGE_INTERVAL_DAYS = 7

# Give brand-new signups a few days to explore before pestering them
# about Pro. Users who registered more recently than this are excluded
# from candidacy entirely (separate from the "already nudged" cooldown
# above).
REGISTERED_GRACE_DAYS = 3

# Safety cap on how many nudge emails a single run/click can send, so
# a bug (or an unexpectedly large candidate pool) can't blast the full
# user base at once.
MAX_NUDGES = 200

# In-app notification copy. Kept as constants so the wording is easy to
# review and change without touching the sending logic.
NUDGE_TITLE = "Get more from CVForge with Pro"
NUDGE_MESSAGE = (
    "Pro gives you unlimited AI generations, DOCX downloads and version "
    "history for every CV you create. Pay with M-Pesa. Each subscription lasts 30 days and does not renew automatically."
)


def get_nudge_candidates():
    """Free-tier users eligible for a Pro-upgrade reminder right now:
    active, verified, opted in to email_newsletter, registered more
    than REGISTERED_GRACE_DAYS ago, and either never nudged or not
    nudged within NUDGE_INTERVAL_DAYS. Capped at MAX_NUDGES."""
    now = utcnow()
    nudge_cutoff = now - timedelta(days=NUDGE_INTERVAL_DAYS)
    registered_cutoff = now - timedelta(days=REGISTERED_GRACE_DAYS)
    return (
        User.query
        .join(UserSettings, UserSettings.user_id == User.id)
        .filter(User.plan == "free")
        .filter(User.is_active.is_(True))
        .filter(User.is_verified.is_(True))
        .filter(UserSettings.email_newsletter.is_(True))
        .filter(User.created_at < registered_cutoff)
        .filter(db.or_(
            UserSettings.last_nudge_sent_at.is_(None),
            UserSettings.last_nudge_sent_at < nudge_cutoff,
        ))
        .order_by(User.created_at.desc())
        .limit(MAX_NUDGES)
        .all()
    )


def send_pro_upgrade_nudges() -> dict:
    """Email every eligible free-tier user a Pro-upgrade reminder, log an
    in-app Notification, and stamp last_nudge_sent_at so they aren't
    nudged again for NUDGE_INTERVAL_DAYS.

    Uses the existing app/services/email_service.send_pro_nudge_email(user)
    helper, which already logs-and-skips instead of raising when mail
    isn't configured (dev/staging) — so a "sent" count here means
    "attempted," not "SMTP confirmed delivery."

    Returns {"sent": int, "failed": int} so callers (admin panel, CLI)
    can report both counts.
    """
    from app.services.email_service import send_pro_nudge_email

    sent = 0
    failed = 0
    for user in get_nudge_candidates():
        try:
            send_pro_nudge_email(user)
        except Exception:
            failed += 1
            continue

        db.session.add(Notification(
            user_id=user.id,
            title=NUDGE_TITLE,
            message=NUDGE_MESSAGE,
            type="upgrade",
            action_url="/billing/plans",
        ))
        user.settings.last_nudge_sent_at = utcnow()
        sent += 1

    db.session.commit()
    return {"sent": sent, "failed": failed}
